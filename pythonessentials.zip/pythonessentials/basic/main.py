from datastructure import DataStructure

'''
 Programador: Rômulo Cesar
 Programa: Hello World
 Objetivo: ambientar o estudante
'''
#NOTE - Python aceita aspas simples e duplas
print("PI Teams")
while True:
    op = input("1-Marlon 2-Marcia 3-Eduardo -0 sair")
    try:
        op_cast = int(op)
        #NOTE - escopo global
        team = DataStructure()
        if op_cast == 1:
          print("Time do Marlon")       
          team.view_variables()
        elif op_cast == 2:
            print("Time da Marcia")
            team.view_variables_two()
        elif op_cast == 3:
            print("Time do Eduardo")
            team.view_variables_three()
        elif op_cast == 0:
            break
    except:
        break


