class DataStructure:
  #NOTE - O que é uma classe?
  #FIXME - uso do pass = não tem corpo

  def view_variables(self):
     team_enem = "Marlon" #NOTE  - tipo str
     number_members = 6   #NOTE  - tipo int 
     project_cost = 120.45 #NOTE - tipo float
     print(f"{team_enem},{number_members},{project_cost}")
     
  def view_variables_two(self):
     team_enem = "Marcia" #NOTE  - tipo str
     number_members = 4   #NOTE  - tipo int 
     project_cost = 90.45 #NOTE - tipo float
     print(f"{team_enem},{number_members},{project_cost}")
     
  def view_variables_three(self):
     team_enem = "Eduardo" #NOTE  - tipo str
     number_members = 7   #NOTE  - tipo int 
     project_cost = 150.45 #NOTE - tipo float
     print(f"{team_enem},{number_members},{project_cost}")


